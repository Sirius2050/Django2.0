from django.apps import AppConfig


class RankingConfig(AppConfig):
    name = 'ranking'
